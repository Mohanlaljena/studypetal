import { existsSync, readFileSync } from "node:fs";

function loadEnv() {
  if (!existsSync(".env")) throw new Error(".env file not found.");
  const env = {};
  for (const line of readFileSync(".env", "utf8").split(/\r?\n/)) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (match) env[match[1]] = match[2];
  }
  return env;
}

const env = loadEnv();
const supabaseUrl = env.VITE_SUPABASE_URL || env.SUPABASE_URL;
const anonKey = env.VITE_SUPABASE_ANON_KEY || env.SUPABASE_ANON_KEY;

if (!supabaseUrl || !anonKey) {
  throw new Error("Missing VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY.");
}

const runId = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
const email = `studypetal.verify+${runId}@gmail.com`;
const password = `Verify-${runId}-Aa1!`;
const created = [];
const checks = [];

function ok(name, detail = "") {
  checks.push({ status: "PASS", name, detail });
}

function fail(name, detail = "") {
  checks.push({ status: "FAIL", name, detail });
}

async function request(path, { method = "GET", token, body, prefer, searchParams } = {}) {
  const url = new URL(path, supabaseUrl);
  if (searchParams) {
    for (const [key, value] of Object.entries(searchParams)) url.searchParams.set(key, value);
  }
  const headers = {
    apikey: anonKey,
    "Content-Type": "application/json"
  };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (prefer) headers.Prefer = prefer;

  const response = await fetch(url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined
  });

  const text = await response.text();
  const data = text ? JSON.parse(text) : null;
  return { response, data };
}

async function expectSuccess(name, promise) {
  const result = await promise;
  if (!result.response.ok) {
    throw new Error(`${name}: ${result.response.status} ${JSON.stringify(result.data)}`);
  }
  ok(name);
  return result.data;
}

async function expectBlocked(name, promise) {
  const result = await promise;
  if (result.response.ok) {
    fail(name, "Request unexpectedly succeeded.");
    return result.data;
  }
  ok(name, `${result.response.status}`);
  return result.data;
}

async function insert(table, token, body) {
  const data = await expectSuccess(
    `${table} insert`,
    request(`/rest/v1/${table}`, {
      method: "POST",
      token,
      body,
      prefer: "return=representation"
    })
  );
  created.push({ table, id: data[0].id });
  return data[0];
}

async function cleanup(token) {
  for (const row of created.reverse()) {
    await request(`/rest/v1/${row.table}`, {
      method: "DELETE",
      token,
      searchParams: { id: `eq.${row.id}` }
    });
  }
}

async function verifyAnonymousDatabaseAccess(reason) {
  ok("Supabase auth endpoint reachable", reason);
  for (const table of ["profiles", "screen_time_entries", "pomodoro_sessions", "study_planner_tasks", "analytics_events"]) {
    await expectSuccess(
      `${table} reachable with anonymous RLS`,
      request(`/rest/v1/${table}`, {
        searchParams: { select: "id", limit: "1" }
      })
    );
  }
  await expectBlocked(
    "RLS blocks anonymous insert",
    request("/rest/v1/screen_time_entries", {
      method: "POST",
      body: {
        user_id: "00000000-0000-0000-0000-000000000000",
        subject: "Maths",
        duration_minutes: 1,
        started_at: new Date().toISOString()
      }
    })
  );
}

let token;
let user;

try {
  const signupResult = await request("/auth/v1/signup", {
    method: "POST",
    body: {
      email,
      password,
      data: { full_name: "StudyPetal Verification" }
    }
  });

  if (!signupResult.response.ok) {
    await verifyAnonymousDatabaseAccess(`${signupResult.response.status} ${signupResult.data?.error_code || signupResult.data?.msg || "signup unavailable"}`);
    fail("Authenticated CRUD", "Skipped because Supabase did not issue a test session.");
    for (const check of checks) {
      console.log(`${check.status}: ${check.name}${check.detail ? ` (${check.detail})` : ""}`);
    }
    process.exit(1);
  }

  ok("Supabase signup");
  const signup = signupResult.data;

  user = signup.user;
  token = signup.access_token;
  if (!token) {
    const login = await request("/auth/v1/token", {
      method: "POST",
      searchParams: { grant_type: "password" },
      body: { email, password }
    });
    if (login.response.ok) {
      token = login.data.access_token;
      user = login.data.user;
      ok("Supabase password login");
    } else {
      ok("Email confirmation required", "Signup worked, but no session token was issued.");
      await verifyAnonymousDatabaseAccess("signup succeeded");
      fail("Authenticated CRUD", "Skipped because the new test user must confirm email before Supabase returns an access token.");
      for (const check of checks) {
        console.log(`${check.status}: ${check.name}${check.detail ? ` (${check.detail})` : ""}`);
      }
      process.exit(1);
    }
  } else {
    ok("Supabase session returned");
  }

  await expectBlocked(
    "RLS blocks anonymous insert",
    request("/rest/v1/screen_time_entries", {
      method: "POST",
      body: {
        user_id: user.id,
        subject: "Maths",
        duration_minutes: 1,
        started_at: new Date().toISOString()
      }
    })
  );

  await expectSuccess(
    "profiles upsert/select",
    request("/rest/v1/profiles", {
      method: "POST",
      token,
      searchParams: { on_conflict: "id" },
      prefer: "resolution=merge-duplicates,return=representation",
      body: {
        id: user.id,
        email,
        full_name: "StudyPetal Verification"
      }
    })
  );

  const startedAt = new Date();
  const screenTime = await insert("screen_time_entries", token, {
    user_id: user.id,
    subject: "Maths",
    duration_minutes: 12,
    started_at: startedAt.toISOString(),
    ended_at: new Date(startedAt.getTime() + 12 * 60000).toISOString(),
    notes: "Verification row"
  });

  const anonSelect = await request("/rest/v1/screen_time_entries", {
    searchParams: { id: `eq.${screenTime.id}`, select: "id" }
  });
  if (anonSelect.response.ok && Array.isArray(anonSelect.data) && anonSelect.data.length === 0) {
    ok("RLS hides owner rows from anonymous select");
  } else {
    fail("RLS hides owner rows from anonymous select", JSON.stringify(anonSelect.data));
  }

  await insert("pomodoro_sessions", token, {
    user_id: user.id,
    subject: "Maths",
    mode: "focus",
    duration_minutes: 25,
    started_at: startedAt.toISOString(),
    ended_at: new Date(startedAt.getTime() + 25 * 60000).toISOString(),
    completed: true
  });

  const task = await insert("study_planner_tasks", token, {
    user_id: user.id,
    title: "Verification task",
    subject: "Maths",
    priority: "medium",
    status: "open",
    notes: "Created by verification script"
  });

  await expectSuccess(
    "study_planner_tasks update",
    request("/rest/v1/study_planner_tasks", {
      method: "PATCH",
      token,
      searchParams: { id: `eq.${task.id}` },
      prefer: "return=representation",
      body: { status: "completed", completed_at: new Date().toISOString() }
    })
  );

  await insert("analytics_events", token, {
    user_id: user.id,
    event_name: "verification_event",
    properties: { run_id: runId },
    user_agent: "scripts/verify-supabase.mjs"
  });

  for (const table of ["profiles", "screen_time_entries", "pomodoro_sessions", "study_planner_tasks", "analytics_events"]) {
    await expectSuccess(
      `${table} authenticated select`,
      request(`/rest/v1/${table}`, {
        token,
        searchParams: { select: "id", limit: "1" }
      })
    );
  }
} finally {
  if (token) await cleanup(token);
}

for (const check of checks) {
  console.log(`${check.status}: ${check.name}${check.detail ? ` (${check.detail})` : ""}`);
}

if (checks.some(check => check.status === "FAIL")) {
  process.exitCode = 1;
}
