import { existsSync, readFileSync, writeFileSync } from "node:fs";

if (existsSync(".env")) {
  const envText = readFileSync(".env", "utf8");
  for (const line of envText.split(/\r?\n/)) {
    const match = line.match(/^([A-Z0-9_]+)=(.*)$/);
    if (match && !process.env[match[1]]) {
      process.env[match[1]] = match[2];
    }
  }
}

const config = {
  SUPABASE_URL: process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || "",
  SUPABASE_ANON_KEY: process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || ""
};

writeFileSync(
  "config.js",
  `window.STUDYPETAL_CONFIG = ${JSON.stringify(config, null, 2)};\n`,
  "utf8"
);

console.log("Generated config.js for StudyPetal.");
