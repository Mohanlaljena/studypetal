create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.screen_time_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null,
  duration_minutes integer not null check (duration_minutes > 0 and duration_minutes <= 1440),
  started_at timestamptz not null,
  ended_at timestamptz,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.pomodoro_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null,
  mode text not null default 'focus' check (mode in ('focus', 'short_break', 'long_break')),
  duration_minutes integer not null check (duration_minutes > 0 and duration_minutes <= 180),
  started_at timestamptz not null,
  ended_at timestamptz,
  completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.study_planner_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  subject text,
  notes text,
  due_date date,
  priority text not null default 'medium' check (priority in ('low', 'medium', 'high')),
  status text not null default 'open' check (status in ('open', 'completed', 'archived')),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.analytics_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  event_name text not null,
  properties jsonb not null default '{}'::jsonb,
  user_agent text,
  created_at timestamptz not null default now()
);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_profiles_updated_at on public.profiles;
create trigger set_profiles_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists set_screen_time_entries_updated_at on public.screen_time_entries;
create trigger set_screen_time_entries_updated_at
before update on public.screen_time_entries
for each row execute function public.set_updated_at();

drop trigger if exists set_pomodoro_sessions_updated_at on public.pomodoro_sessions;
create trigger set_pomodoro_sessions_updated_at
before update on public.pomodoro_sessions
for each row execute function public.set_updated_at();

drop trigger if exists set_study_planner_tasks_updated_at on public.study_planner_tasks;
create trigger set_study_planner_tasks_updated_at
before update on public.study_planner_tasks
for each row execute function public.set_updated_at();

create index if not exists screen_time_entries_user_started_idx
  on public.screen_time_entries(user_id, started_at desc);

create index if not exists pomodoro_sessions_user_started_idx
  on public.pomodoro_sessions(user_id, started_at desc);

create index if not exists study_planner_tasks_user_due_idx
  on public.study_planner_tasks(user_id, due_date, status);

create index if not exists analytics_events_user_created_idx
  on public.analytics_events(user_id, created_at desc);

alter table public.profiles enable row level security;
alter table public.screen_time_entries enable row level security;
alter table public.pomodoro_sessions enable row level security;
alter table public.study_planner_tasks enable row level security;
alter table public.analytics_events enable row level security;

drop policy if exists "Profiles are private" on public.profiles;
create policy "Profiles are private"
on public.profiles
for select
using (auth.uid() = id);

drop policy if exists "Users can insert their profile" on public.profiles;
create policy "Users can insert their profile"
on public.profiles
for insert
with check (auth.uid() = id);

drop policy if exists "Users can update their profile" on public.profiles;
create policy "Users can update their profile"
on public.profiles
for update
using (auth.uid() = id)
with check (auth.uid() = id);

drop policy if exists "Screen time belongs to owner" on public.screen_time_entries;
create policy "Screen time belongs to owner"
on public.screen_time_entries
for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Pomodoros belong to owner" on public.pomodoro_sessions;
create policy "Pomodoros belong to owner"
on public.pomodoro_sessions
for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Planner tasks belong to owner" on public.study_planner_tasks;
create policy "Planner tasks belong to owner"
on public.study_planner_tasks
for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

drop policy if exists "Analytics belongs to owner" on public.analytics_events;
create policy "Analytics belongs to owner"
on public.analytics_events
for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
