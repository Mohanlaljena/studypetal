import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { AnimatePresence, motion } from "framer-motion";
import { createClient } from "@supabase/supabase-js";

const h = React.createElement;
const config = {
  SUPABASE_URL: import.meta.env.VITE_SUPABASE_URL || window.STUDYPETAL_CONFIG?.SUPABASE_URL || "",
  SUPABASE_ANON_KEY: import.meta.env.VITE_SUPABASE_ANON_KEY || window.STUDYPETAL_CONFIG?.SUPABASE_ANON_KEY || ""
};
const hasSupabaseConfig = Boolean(config.SUPABASE_URL && config.SUPABASE_ANON_KEY);
const supabase = hasSupabaseConfig
  ? createClient(config.SUPABASE_URL, config.SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
    })
  : null;

const subjects = ["Maths", "Physics", "Chemistry", "CS", "English", "Biology", "History", "Geography"];
const protectedRoutes = new Set(["dashboard", "timer", "tasks", "progress", "log"]);
const navLabels = { home: "Home", dashboard: "Dashboard", timer: "Timer", tasks: "Tasks", progress: "Progress", log: "Log" };
const m = motion;

function App() {
  const [route, setRoute] = useState(getRoute());
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [toasts, setToasts] = useState([]);
  const [data, setData] = useState({ screenTime: [], pomodoros: [], tasks: [], analytics: [] });
  const [timer, setTimer] = useState({
    secondsLeft: 25 * 60,
    totalSeconds: 25 * 60,
    subject: "Maths",
    mode: "focus",
    running: false,
    startedAt: null
  });

  const userId = session?.user?.id;
  const notify = (message, type = "success") => {
    const id = crypto.randomUUID();
    setToasts(items => [...items, { id, message, type }]);
    window.setTimeout(() => setToasts(items => items.filter(item => item.id !== id)), 4200);
  };
  const fail = error => notify(error?.message || "Something went wrong.", "error");
  const navigate = nextRoute => {
    location.hash = `#/${nextRoute}`;
  };

  useEffect(() => {
    const onHash = () => setRoute(getRoute());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  useEffect(() => {
    async function boot() {
      if (!hasSupabaseConfig) {
        setLoading(false);
        notify("Add Supabase environment variables before using the app.", "error");
        return;
      }
      const { data: authData, error } = await supabase.auth.getSession();
      if (error) fail(error);
      setSession(authData.session);
      setLoading(false);
    }
    boot();

    if (!supabase) return undefined;
    const { data: sub } = supabase.auth.onAuthStateChange(async (_event, nextSession) => {
      setSession(nextSession);
      if (!nextSession) {
        setProfile(null);
        setData({ screenTime: [], pomodoros: [], tasks: [], analytics: [] });
        setTimer(prev => ({ ...prev, running: false }));
      }
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!loading && protectedRoutes.has(route) && !session) navigate("login");
  }, [route, session, loading]);

  useEffect(() => {
    if (!session) return;
    ensureProfile(session).then(setProfile).catch(fail);
    loadDashboardData();
    if (["home", "login", "signup"].includes(route)) navigate("dashboard");
  }, [session?.user?.id]);

  useEffect(() => {
    if (!session || !protectedRoutes.has(route)) return;
    recordEvent("page_view", { route }).catch(() => {});
  }, [route, session?.user?.id]);

  useEffect(() => {
    if (!timer.running) return undefined;
    const id = window.setInterval(() => {
      setTimer(prev => ({ ...prev, secondsLeft: Math.max(0, prev.secondsLeft - 1) }));
    }, 1000);
    return () => window.clearInterval(id);
  }, [timer.running]);

  useEffect(() => {
    if (timer.running && timer.secondsLeft === 0) finishPomodoro(timer).catch(fail);
  }, [timer.secondsLeft, timer.running]);

  async function ensureProfile(activeSession) {
    const email = activeSession.user.email;
    const fullName = activeSession.user.user_metadata?.full_name || email?.split("@")[0] || "StudyPetal learner";
    const { data: row, error } = await supabase
      .from("profiles")
      .upsert({ id: activeSession.user.id, email, full_name: fullName }, { onConflict: "id" })
      .select()
      .single();
    if (error) throw error;
    return row;
  }

  async function loadDashboardData() {
    if (!session?.user?.id) return;
    setBusy(true);
    try {
      const today = new Date().toISOString().slice(0, 10);
      const [screenTime, pomodoros, tasks, analytics] = await Promise.all([
        supabase.from("screen_time_entries").select("*").order("started_at", { ascending: false }).limit(50),
        supabase.from("pomodoro_sessions").select("*").order("started_at", { ascending: false }).limit(50),
        supabase.from("study_planner_tasks").select("*").order("due_date", { ascending: true }).limit(100),
        supabase.from("analytics_events").select("*").gte("created_at", `${today}T00:00:00`).order("created_at", { ascending: false }).limit(100)
      ]);
      for (const result of [screenTime, pomodoros, tasks, analytics]) if (result.error) throw result.error;
      setData({
        screenTime: screenTime.data || [],
        pomodoros: pomodoros.data || [],
        tasks: tasks.data || [],
        analytics: analytics.data || []
      });
    } finally {
      setBusy(false);
    }
  }

  async function login(values) {
    const { error } = await supabase.auth.signInWithPassword(values);
    if (error) throw error;
    notify("Logged in.");
  }

  async function signup(values) {
    const { error } = await supabase.auth.signUp({
      email: values.email,
      password: values.password,
      options: { data: { full_name: values.full_name } }
    });
    if (error) throw error;
    notify("Account created. Check your email if confirmation is enabled.");
  }

  async function logout() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    notify("Signed out.");
    navigate("home");
  }

  async function createTask(values, form) {
    const { error } = await supabase.from("study_planner_tasks").insert({
      user_id: userId,
      title: values.title,
      subject: values.subject,
      due_date: values.due_date || null,
      priority: values.priority,
      notes: values.notes || null,
      status: "open"
    });
    if (error) throw error;
    await recordEvent("task_created", { subject: values.subject, priority: values.priority });
    form.reset();
    await loadDashboardData();
    notify("Task added.");
  }

  async function toggleTask(id) {
    const task = data.tasks.find(item => item.id === id);
    const status = task?.status === "completed" ? "open" : "completed";
    const { error } = await supabase
      .from("study_planner_tasks")
      .update({ status, completed_at: status === "completed" ? new Date().toISOString() : null })
      .eq("id", id);
    if (error) throw error;
    await recordEvent("task_updated", { status });
    await loadDashboardData();
    notify(status === "completed" ? "Task completed." : "Task reopened.");
  }

  async function createScreenTime(values, form) {
    await createScreenTimeRecord(values);
    await recordEvent("screen_time_created", { subject: values.subject, duration_minutes: Number(values.duration_minutes) });
    form.reset();
    await loadDashboardData();
    notify("Screen time saved.");
  }

  async function createScreenTimeRecord(values) {
    const startedAt = new Date(values.started_at);
    const duration = Number(values.duration_minutes);
    const { error } = await supabase.from("screen_time_entries").insert({
      user_id: userId,
      subject: values.subject,
      duration_minutes: duration,
      started_at: startedAt.toISOString(),
      ended_at: new Date(startedAt.getTime() + duration * 60000).toISOString(),
      notes: values.notes || null
    });
    if (error) throw error;
  }

  async function deleteRow(table, id, message) {
    const { error } = await supabase.from(table).delete().eq("id", id);
    if (error) throw error;
    await recordEvent(`${table}_deleted`, { id });
    await loadDashboardData();
    notify(message);
  }

  async function recordEvent(eventName, properties = {}) {
    if (!session?.user?.id) return;
    await supabase.from("analytics_events").insert({
      user_id: session.user.id,
      event_name: eventName,
      properties,
      user_agent: navigator.userAgent
    });
  }

  function saveTimerSettings(values) {
    const totalSeconds = Number(values.minutes) * 60;
    setTimer(prev => ({ ...prev, subject: values.subject, totalSeconds, secondsLeft: totalSeconds, startedAt: null }));
    notify("Timer settings saved.");
  }

  function startTimer() {
    setTimer(prev => ({ ...prev, running: true, startedAt: prev.startedAt || new Date() }));
    recordEvent("timer_started", { subject: timer.subject }).catch(() => {});
  }

  function pauseTimer() {
    setTimer(prev => ({ ...prev, running: false }));
    recordEvent("timer_paused", { seconds_left: timer.secondsLeft }).catch(() => {});
  }

  function resetTimer() {
    setTimer(prev => ({ ...prev, running: false, secondsLeft: prev.totalSeconds, startedAt: null }));
  }

  async function finishPomodoro(snapshot) {
    const startedAt = snapshot.startedAt || new Date(Date.now() - snapshot.totalSeconds * 1000);
    const durationMinutes = Math.round(snapshot.totalSeconds / 60);
    setTimer(prev => ({ ...prev, running: false, secondsLeft: prev.totalSeconds, startedAt: null }));
    const payload = {
      user_id: userId,
      subject: snapshot.subject,
      mode: snapshot.mode,
      duration_minutes: durationMinutes,
      started_at: startedAt.toISOString(),
      ended_at: new Date().toISOString(),
      completed: true
    };
    const { error } = await supabase.from("pomodoro_sessions").insert(payload);
    if (error) throw error;
    await createScreenTimeRecord({
      subject: snapshot.subject,
      duration_minutes: durationMinutes,
      started_at: payload.started_at,
      notes: "Saved from Pomodoro timer"
    });
    await recordEvent("pomodoro_completed", { subject: snapshot.subject, duration_minutes: durationMinutes });
    await loadDashboardData();
    notify("Pomodoro saved.");
  }

  const stats = useMemo(() => getStats(data), [data]);
  const actions = {
    busy,
    data,
    fail,
    loadDashboardData,
    login,
    signup,
    logout,
    navigate,
    createTask,
    toggleTask,
    createScreenTime,
    deleteRow,
    saveTimerSettings,
    startTimer,
    pauseTimer,
    resetTimer,
    setTimer,
    timer
  };

  return h(React.Fragment, null,
    h("div", { className: "ambient-bg", "aria-hidden": "true" },
      h("span", { className: "aurora aurora-one" }),
      h("span", { className: "aurora aurora-two" }),
      h("span", { className: "aurora aurora-three" }),
      h("span", { className: "grid-glow" })
    ),
    h("div", { className: "app-shell" },
      h(Topbar, { route, session, actions }),
      h(AnimatePresence, { mode: "wait" },
        loading
          ? h(LoadingView, { key: "loading" })
          : h(RouteView, { key: route, route, session, profile, stats, actions })
      )
    ),
    h(ToastStack, { toasts })
  );
}

function RouteView({ route, session, profile, stats, actions }) {
  if (!hasSupabaseConfig) return h(MissingConfigView);
  if (protectedRoutes.has(route) && !session) return h(AuthView, { mode: "login", actions });
  if (route === "login") return h(AuthView, { mode: "login", actions });
  if (route === "signup") return h(AuthView, { mode: "signup", actions });
  if (route === "dashboard") return h(DashboardView, { active: "dashboard", profile, stats, actions });
  if (["timer", "tasks", "progress", "log"].includes(route)) return h(DashboardView, { active: route, profile, stats, actions });
  return h(HomeView, { actions });
}

function Topbar({ route, session, actions }) {
  const navItems = session ? ["dashboard", "timer", "tasks", "progress", "log"] : ["home", "login", "signup"];
  return h(m.header, { className: "topbar glass", initial: { y: -18, opacity: 0 }, animate: { y: 0, opacity: 1 } },
    h("button", { className: "brand", type: "button", onClick: () => actions.navigate("home") },
      h("span", { className: "brand-mark" }, "SP"),
      h("span", null, "StudyPetal")
    ),
    h("nav", { className: "nav", "aria-label": "Primary" },
      navItems.map(item => h(MotionButton, {
        key: item,
        className: "nav-button",
        "aria-current": route === item ? "page" : "false",
        onClick: () => actions.navigate(item)
      }, navLabels[item] || title(item))),
      session ? h(MotionButton, { className: "nav-button", onClick: () => actions.logout().catch(actions.fail) }, "Sign out") : null
    )
  );
}

function HomeView({ actions }) {
  return h(Page, null,
    h("main", { className: "hero premium-hero" },
      h(m.section, { className: "hero-copy", variants: stagger, initial: "hidden", animate: "show" },
        h(m.p, { className: "eyebrow", variants: rise }, "AI-ready study command center"),
        h(m.h1, { variants: rise }, "Study beautifully. Focus deeply. Grow daily."),
        h(m.p, { className: "hero-lede", variants: rise }, "A premium study tracker with Supabase auth, protected dashboards, Pomodoro history, planner tasks, analytics, and screen-time logs synced across devices."),
        h(m.div, { className: "hero-actions", variants: rise },
          h(MotionButton, { className: "primary-button", onClick: () => actions.navigate("signup") }, "Create account"),
          h(MotionButton, { className: "ghost-button", onClick: () => actions.navigate("login") }, "Log in")
        )
      ),
      h(m.aside, { className: "hero-console glass", initial: { opacity: 0, scale: 0.94, rotateX: 12 }, animate: { opacity: 1, scale: 1, rotateX: 0 }, transition: spring },
        h("div", { className: "console-orbit" }),
        h("div", { className: "console-header" },
          h("span", null, "Live Focus Stack"),
          h("strong", null, "92%")
        ),
        h("div", { className: "focus-ring" }, h("span", null, "25:00")),
        h("div", { className: "preview-grid" },
          h(PreviewTile, { label: "Today", value: "2h 30m", delay: 0.1 }),
          h(PreviewTile, { label: "Tasks", value: "5 done", delay: 0.18 }),
          h(PreviewTile, { label: "Focus", value: "4 rounds", delay: 0.26 })
        ),
        h("div", { className: "sparkline", "aria-hidden": "true" }, [32, 54, 42, 68, 57, 84, 76].map((height, index) => h("i", { key: index, style: { height: `${height}%` } })))
      )
    )
  );
}

function AuthView({ mode, actions }) {
  const isSignup = mode === "signup";
  return h(Page, null,
    h("main", { className: "auth-wrap" },
      h(m.section, { className: "auth-panel glass", initial: { opacity: 0, y: 30, scale: 0.96 }, animate: { opacity: 1, y: 0, scale: 1 }, exit: { opacity: 0, y: -20 }, transition: spring },
        h("p", { className: "eyebrow" }, isSignup ? "Start blooming" : "Welcome back"),
        h("h1", null, isSignup ? "Create account" : "Log in"),
        h("form", { className: "form-grid", onSubmit: event => submitForm(event, values => isSignup ? actions.signup(values) : actions.login(values), actions) },
          isSignup ? h(Field, { label: "Full name", name: "full_name", type: "text", placeholder: "Ada Lovelace" }) : null,
          h(Field, { label: "Email", name: "email", type: "email", placeholder: "you@example.com", required: true }),
          h(Field, { label: "Password", name: "password", type: "password", placeholder: "At least 6 characters", required: true }),
          h("div", { className: "form-actions" },
            h(MotionButton, { className: "primary-button", type: "submit" }, isSignup ? "Sign up" : "Log in"),
            h(MotionButton, { className: "ghost-button", type: "button", onClick: () => actions.navigate(isSignup ? "login" : "signup") }, isSignup ? "I have an account" : "Create account")
          )
        )
      )
    )
  );
}

function DashboardView({ active, profile, stats, actions }) {
  const chartData = useMemo(() => buildDailyMinutes(actions.data.screenTime), [actions.data.screenTime]);
  const subjectData = useMemo(() => buildSubjectBreakdown(actions.data.screenTime), [actions.data.screenTime]);
  const productivityScore = getProductivityScore(stats);

  return h(Page, null,
    h("main", { className: "dashboard" },
      h(m.section, { className: "dashboard-header", variants: stagger, initial: "hidden", animate: "show" },
        h(m.div, { variants: rise },
          h("p", { className: "eyebrow" }, `Hello ${profile?.full_name || "learner"}`),
          h("h1", null, active === "dashboard" ? "Dashboard" : navLabels[active])
        ),
        h(m.div, { className: "header-actions", variants: rise },
          actions.busy ? h("span", { className: "sync-pill" }, "Syncing") : h("span", { className: "sync-pill ready" }, "Synced"),
          h(MotionButton, { className: "ghost-button", onClick: () => actions.loadDashboardData().catch(actions.fail) }, "Refresh")
        )
      ),
      h(DashboardHero, { stats, productivityScore, chartData }),
      h("section", { className: "stats-grid premium-stats" },
        h(StatCard, { label: "Deep Work", value: formatMinutes(stats.todayMinutes), caption: "tracked today", tone: "mint", index: 0 }),
        h(StatCard, { label: "Focus Rounds", value: stats.focusSessions, caption: "completed Pomodoros", tone: "violet", index: 1 }),
        h(StatCard, { label: "Tasks Done", value: stats.completedTasks, caption: `${stats.openTasks} still open`, tone: "gold", index: 2 }),
        h(StatCard, { label: "Momentum", value: `${productivityScore}%`, caption: "productivity signal", tone: "pink", index: 3 })
      ),
      active === "dashboard" ? h(OverviewPanels, { actions }) : null,
      active === "timer" ? h(TimerPanel, { actions }) : null,
      active === "tasks" ? h(TasksPanel, { actions }) : null,
      active === "progress" ? h(ProgressPanel, { stats, actions, chartData, subjectData, productivityScore }) : null,
      active === "log" ? h(LogPanel, { actions }) : null
    )
  );
}

function OverviewPanels({ actions }) {
  const stats = getStats(actions.data);
  const chartData = buildDailyMinutes(actions.data.screenTime);
  const subjectData = buildSubjectBreakdown(actions.data.screenTime);
  const productivityScore = getProductivityScore(stats);

  return h(React.Fragment, null,
    h("section", { className: "dashboard-grid" },
      h(FocusChartPanel, { chartData }),
      h(ProductivityPanel, { stats, productivityScore }),
      h(SubjectRingsPanel, { subjectData })
    ),
    h("section", { className: "layout-grid" },
      h(TimerPanel, { actions }),
      h(TasksPanel, { actions, compact: true })
    ),
    h(LogPanel, { actions, compact: true })
  );
}

function TimerPanel({ actions }) {
  const timer = actions.timer;
  return h(Panel, { title: "Pomodoro Timer", className: "timer-panel" },
    h("div", { className: "timer-face-wrap" },
      h(m.div, { className: "timer-face", animate: { boxShadow: timer.running ? "0 0 80px rgba(103,232,249,.42)" : "0 22px 60px rgba(13,18,38,.22)" }, transition: { duration: 0.7 } },
        h("span", null, formatClock(timer.secondsLeft))
      )
    ),
    h("form", { className: "form-grid", onSubmit: event => submitForm(event, actions.saveTimerSettings, actions) },
      h("label", { className: "field" }, h("span", null, "Subject"), h(SubjectSelect, { name: "subject", value: timer.subject })),
      h(Field, { label: "Focus minutes", name: "minutes", type: "number", min: "1", max: "180", defaultValue: Math.round(timer.totalSeconds / 60), required: true }),
      h("div", { className: "form-actions" },
        h(MotionButton, { className: "primary-button", type: "button", onClick: timer.running ? actions.pauseTimer : actions.startTimer }, timer.running ? "Pause" : "Start"),
        h(MotionButton, { className: "ghost-button", type: "button", onClick: actions.resetTimer }, "Reset"),
        h(MotionButton, { className: "ghost-button", type: "submit" }, "Save settings")
      )
    ),
    h("div", { className: "quick-subjects" },
      subjects.map(subject => h(MotionButton, { key: subject, type: "button", onClick: () => actions.setTimer(prev => ({ ...prev, subject })) }, subject))
    )
  );
}

function TasksPanel({ actions, compact = false }) {
  const tasks = compact ? actions.data.tasks.slice(0, 4) : actions.data.tasks;
  return h(Panel, { title: "Study Planner", className: "tasks-panel" },
    h("form", { className: "form-grid", onSubmit: event => submitForm(event, (values, form) => actions.createTask(values, form), actions) },
      h(Field, { label: "Title", name: "title", type: "text", placeholder: "Read chapter 4", required: true }),
      h("label", { className: "field" }, h("span", null, "Subject"), h(SubjectSelect, { name: "subject" })),
      h(Field, { label: "Due date", name: "due_date", type: "date" }),
      h("label", { className: "field" }, h("span", null, "Priority"), h("select", { name: "priority", defaultValue: "medium" }, ["low", "medium", "high"].map(item => h("option", { key: item, value: item }, title(item))))),
      h("label", { className: "field wide-field" }, h("span", null, "Notes"), h("textarea", { name: "notes", placeholder: "Optional details" })),
      h(MotionButton, { className: "primary-button", type: "submit" }, "Add task")
    ),
    h("div", { className: "list" }, tasks.length ? tasks.map((task, index) => h(TaskItem, { key: task.id, task, index, actions })) : h(EmptyState, { message: "No planner tasks yet." }))
  );
}

function ProgressPanel({ stats, actions, chartData = buildDailyMinutes(actions.data.screenTime), subjectData = buildSubjectBreakdown(actions.data.screenTime), productivityScore = getProductivityScore(stats) }) {
  return h(Panel, { title: "Analytics", className: "analytics-panel" },
    h("section", { className: "dashboard-grid progress-grid" },
      h(FocusChartPanel, { chartData }),
      h(ProductivityPanel, { stats, productivityScore }),
      h(SubjectRingsPanel, { subjectData })
    ),
    h("div", { className: "preview-grid" },
      h(PreviewTile, { label: "Logged minutes", value: stats.totalMinutes }),
      h(PreviewTile, { label: "Open tasks", value: stats.openTasks }),
      h(PreviewTile, { label: "Events today", value: actions.data.analytics.length })
    ),
    h("div", { className: "analytics-bars" }, [stats.todayMinutes || 8, stats.completedTasks * 18 + 20, stats.focusSessions * 16 + 24, stats.openTasks * 14 + 18].map((value, index) =>
      h(m.i, { key: index, initial: { height: 8 }, animate: { height: Math.min(100, value) }, transition: { delay: index * 0.08, type: "spring", stiffness: 120 } })
    )),
    h("h3", null, "Recent activity"),
    h("div", { className: "list" }, actions.data.analytics.length ? actions.data.analytics.slice(0, 8).map((event, index) => h(EventItem, { key: event.id, event, index })) : h(EmptyState, { message: "No analytics events yet." }))
  );
}

function LogPanel({ actions, compact = false }) {
  const entries = compact ? actions.data.screenTime.slice(0, 4) : actions.data.screenTime;
  return h(Panel, { title: "Screen Time Log", className: "log-panel" },
    h("form", { className: "form-grid", onSubmit: event => submitForm(event, (values, form) => actions.createScreenTime(values, form), actions) },
      h("label", { className: "field" }, h("span", null, "Subject"), h(SubjectSelect, { name: "subject" })),
      h(Field, { label: "Minutes", name: "duration_minutes", type: "number", min: "1", max: "1440", placeholder: "45", required: true }),
      h(Field, { label: "Started at", name: "started_at", type: "datetime-local", defaultValue: datetimeLocalValue(new Date()), required: true }),
      h("label", { className: "field wide-field" }, h("span", null, "Notes"), h("textarea", { name: "notes", placeholder: "What did you study?" })),
      h(MotionButton, { className: "primary-button", type: "submit" }, "Save entry")
    ),
    h("div", { className: "list" }, entries.length ? entries.map((entry, index) => h(ScreenTimeItem, { key: entry.id, entry, index, actions })) : h(EmptyState, { message: "No screen time logged yet." }))
  );
}

function Panel({ title, className = "", children }) {
  return h(m.section, { className: `panel glass ${className}`, initial: { opacity: 0, y: 22 }, whileInView: { opacity: 1, y: 0 }, viewport: { once: true, margin: "-80px" }, transition: spring },
    h("h2", null, title),
    children
  );
}

function DashboardHero({ stats, productivityScore, chartData }) {
  const bestDay = chartData.reduce((best, day) => day.minutes > best.minutes ? day : best, chartData[0]);
  return h(m.section, {
    className: "dashboard-hero glass",
    initial: { opacity: 0, y: 24, scale: 0.98 },
    animate: { opacity: 1, y: 0, scale: 1 },
    transition: spring
  },
    h("div", { className: "dashboard-hero-copy" },
      h("p", { className: "eyebrow" }, "Productivity cockpit"),
      h("h2", null, "Your focus system is online."),
      h("p", { className: "muted" }, `You have logged ${formatMinutes(stats.totalMinutes)} overall, completed ${stats.completedTasks} tasks, and built a ${productivityScore}% momentum score.`),
      h("div", { className: "hero-chip-row" },
        h("span", { className: "hero-chip" }, `Peak day: ${bestDay.label}`),
        h("span", { className: "hero-chip" }, `${formatMinutes(bestDay.minutes)} best streak block`),
        h("span", { className: "hero-chip" }, `${stats.openTasks} active priorities`)
      )
    ),
    h("div", { className: "orbital-score" },
      h(m.div, {
        className: "score-ring",
        style: { "--score": `${productivityScore * 3.6}deg` },
        initial: { rotate: -18, scale: 0.9 },
        animate: { rotate: 0, scale: 1 },
        transition: { ...spring, delay: 0.15 }
      },
        h("strong", null, `${productivityScore}%`),
        h("span", null, "Momentum")
      )
    )
  );
}

function FocusChartPanel({ chartData }) {
  const max = Math.max(...chartData.map(day => day.minutes), 45);
  const points = chartData.map((day, index) => {
    const x = 18 + index * (264 / Math.max(1, chartData.length - 1));
    const y = 122 - (day.minutes / max) * 86;
    return `${x},${y}`;
  }).join(" ");

  return h(m.section, { className: "chart-card glass", whileHover: { y: -5 }, transition: spring },
    h("div", { className: "panel-title-row" },
      h("div", null, h("p", { className: "eyebrow" }, "Weekly focus"), h("h3", null, "Study rhythm")),
      h("span", { className: "chart-badge" }, "Live")
    ),
    h("svg", { className: "line-chart", viewBox: "0 0 300 150", role: "img", "aria-label": "Weekly study minutes chart" },
      h("defs", null,
        h("linearGradient", { id: "lineGradient", x1: "0", x2: "1", y1: "0", y2: "0" },
          h("stop", { offset: "0%", stopColor: "#6ee7b7" }),
          h("stop", { offset: "55%", stopColor: "#67e8f9" }),
          h("stop", { offset: "100%", stopColor: "#a78bfa" })
        )
      ),
      [38, 66, 94, 122].map(y => h("line", { key: y, x1: "16", x2: "284", y1: y, y2: y, className: "chart-grid-line" })),
      h(m.polyline, { points, fill: "none", stroke: "url(#lineGradient)", strokeWidth: "5", strokeLinecap: "round", strokeLinejoin: "round", initial: { pathLength: 0 }, animate: { pathLength: 1 }, transition: { duration: 1.2, ease: "easeOut" } }),
      chartData.map((day, index) => {
        const [x, y] = points.split(" ")[index].split(",");
        return h(m.circle, { key: day.label, cx: x, cy: y, r: "5", initial: { scale: 0 }, animate: { scale: 1 }, transition: { delay: 0.15 + index * 0.05 }, className: "chart-dot" });
      })
    ),
    h("div", { className: "chart-labels" }, chartData.map(day => h("span", { key: day.label }, day.label)))
  );
}

function ProductivityPanel({ stats, productivityScore }) {
  const rows = [
    ["Focus minutes", Math.min(100, Math.round((stats.todayMinutes / 180) * 100) || 12), "mint"],
    ["Task closure", Math.min(100, Math.round((stats.completedTasks / Math.max(1, stats.completedTasks + stats.openTasks)) * 100) || 18), "violet"],
    ["Pomodoro flow", Math.min(100, stats.focusSessions * 12 || 10), "gold"]
  ];

  return h(m.section, { className: "productivity-card glass", whileHover: { y: -5 }, transition: spring },
    h("div", { className: "panel-title-row" },
      h("div", null, h("p", { className: "eyebrow" }, "Operating score"), h("h3", null, `${productivityScore}% aligned`))
    ),
    h("div", { className: "progress-stack" }, rows.map(([label, value, tone], index) =>
      h("div", { className: "progress-row", key: label },
        h("div", { className: "progress-copy" }, h("span", null, label), h("strong", null, `${value}%`)),
        h("div", { className: `progress-track progress-${tone}` },
          h(m.i, { initial: { width: 0 }, animate: { width: `${value}%` }, transition: { delay: index * 0.12, duration: 0.75, ease: "easeOut" } })
        )
      )
    ))
  );
}

function SubjectRingsPanel({ subjectData }) {
  return h(m.section, { className: "subject-card glass", whileHover: { y: -5 }, transition: spring },
    h("div", { className: "panel-title-row" },
      h("div", null, h("p", { className: "eyebrow" }, "Subject mix"), h("h3", null, "Energy allocation"))
    ),
    h("div", { className: "subject-rings" }, subjectData.map((subject, index) =>
      h("div", { className: "subject-ring-item", key: subject.label },
        h(m.div, {
          className: "mini-ring",
          style: { "--ring": `${subject.percent * 3.6}deg`, "--accent": subject.color },
          initial: { scale: 0.82, opacity: 0 },
          animate: { scale: 1, opacity: 1 },
          transition: { delay: index * 0.08, ...spring }
        }, h("span", null, `${subject.percent}%`)),
        h("strong", null, subject.label),
        h("small", null, formatMinutes(subject.minutes))
      )
    ))
  );
}

function TaskItem({ task, index, actions }) {
  return h(m.article, { className: "list-item glass-lite", initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { delay: index * 0.04 } },
    h("div", { className: "list-item-header" },
      h("p", { className: "list-item-title" }, task.title),
      h("div", { className: "row-actions" },
        h(MotionButton, { className: "ghost-button compact", onClick: () => actions.toggleTask(task.id).catch(actions.fail) }, task.status === "completed" ? "Reopen" : "Done"),
        h(MotionButton, { className: "danger-button compact", onClick: () => actions.deleteRow("study_planner_tasks", task.id, "Task deleted.").catch(actions.fail) }, "Delete")
      )
    ),
    h("p", { className: "muted" }, task.notes || "No notes"),
    h(PillRow, { items: [task.subject || "General", task.priority, task.status, task.due_date ? `Due ${task.due_date}` : null] })
  );
}

function ScreenTimeItem({ entry, index, actions }) {
  return h(m.article, { className: "list-item glass-lite", initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { delay: index * 0.04 } },
    h("div", { className: "list-item-header" },
      h("p", { className: "list-item-title" }, `${entry.subject} - ${entry.duration_minutes} minutes`),
      h(MotionButton, { className: "danger-button compact", onClick: () => actions.deleteRow("screen_time_entries", entry.id, "Entry deleted.").catch(actions.fail) }, "Delete")
    ),
    h("p", { className: "muted" }, `${entry.notes || "No notes"} · ${new Date(entry.started_at).toLocaleString()}`)
  );
}

function EventItem({ event, index }) {
  return h(m.article, { className: "list-item glass-lite", initial: { opacity: 0, x: -12 }, animate: { opacity: 1, x: 0 }, transition: { delay: index * 0.04 } },
    h("p", { className: "list-item-title" }, event.event_name),
    h("p", { className: "muted" }, new Date(event.created_at).toLocaleString())
  );
}

function StatCard({ label, value, caption, tone, index }) {
  return h(m.div, { className: `stat-card glass stat-${tone}`, initial: { opacity: 0, y: 20, scale: 0.96 }, animate: { opacity: 1, y: 0, scale: 1 }, transition: { ...spring, delay: index * 0.08 }, whileHover: { y: -6, scale: 1.02 } },
    h("span", { className: "stat-icon" }, ["01", "02", "03", "04"][index] || "SP"),
    h("span", { className: "eyebrow" }, label),
    h("span", { className: "metric" }, value),
    caption ? h("span", { className: "stat-caption" }, caption) : null,
    h("span", { className: "stat-shine" })
  );
}

function PreviewTile({ label, value, delay = 0 }) {
  return h(m.div, { className: "preview-tile glass-lite", initial: { opacity: 0, y: 16 }, animate: { opacity: 1, y: 0 }, transition: { delay } },
    h("span", { className: "eyebrow" }, label),
    h("span", { className: "metric" }, value)
  );
}

function Field({ label, name, type, placeholder, required, defaultValue, min, max }) {
  return h("label", { className: "field" },
    h("span", null, label),
    h("input", { name, type, placeholder, required, defaultValue, min, max })
  );
}

function SubjectSelect({ name, value }) {
  return h("select", { name, defaultValue: value || "Maths" }, subjects.map(subject => h("option", { key: subject, value: subject }, subject)));
}

function MotionButton({ children, ...props }) {
  return h(m.button, { whileHover: { y: -2, scale: 1.02 }, whileTap: { scale: 0.97 }, transition: { type: "spring", stiffness: 420, damping: 26 }, ...props }, children);
}

function EmptyState({ message }) {
  return h("div", { className: "empty-state" }, message);
}

function PillRow({ items }) {
  return h("div", { className: "pill-row" }, items.filter(Boolean).map(item => h("span", { className: "pill", key: item }, item)));
}

function LoadingView() {
  return h("main", { className: "loading-screen" },
    h(m.div, { className: "loader glass", animate: { rotate: 360 }, transition: { duration: 1.2, repeat: Infinity, ease: "linear" } }),
    h("p", null, "Loading StudyPetal...")
  );
}

function MissingConfigView() {
  return h(Page, null,
    h("main", { className: "auth-wrap" },
      h("section", { className: "auth-panel glass" },
        h("p", { className: "eyebrow" }, "Setup required"),
        h("h1", null, "Connect Supabase"),
        h("p", { className: "muted" }, "Create config.js from config.example.js, or set SUPABASE_URL and SUPABASE_ANON_KEY in Netlify.")
      )
    )
  );
}

function ToastStack({ toasts }) {
  return h("div", { className: "toast-root", "aria-live": "assertive", "aria-atomic": "true" },
    h(AnimatePresence, null, toasts.map(toast => h(m.div, { key: toast.id, className: `toast ${toast.type}`, initial: { opacity: 0, y: 18, scale: 0.96 }, animate: { opacity: 1, y: 0, scale: 1 }, exit: { opacity: 0, x: 40 } }, toast.message)))
  );
}

function Page({ children }) {
  return h(m.div, { initial: { opacity: 0, y: 18 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: -18 }, transition: { duration: 0.35 } }, children);
}

function submitForm(event, handler, actions) {
  event.preventDefault();
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form));
  handler(values, form).catch(actions.fail);
}

function getRoute() {
  return location.hash.replace("#/", "") || "home";
}

function getStats(data) {
  const today = new Date().toISOString().slice(0, 10);
  const todayMinutes = data.screenTime.filter(entry => entry.started_at?.slice(0, 10) === today).reduce((sum, entry) => sum + Number(entry.duration_minutes || 0), 0);
  const totalMinutes = data.screenTime.reduce((sum, entry) => sum + Number(entry.duration_minutes || 0), 0);
  return {
    todayMinutes,
    totalMinutes,
    focusSessions: data.pomodoros.filter(item => item.completed).length,
    completedTasks: data.tasks.filter(task => task.status === "completed").length,
    openTasks: data.tasks.filter(task => task.status !== "completed").length
  };
}

function buildDailyMinutes(entries) {
  const formatter = new Intl.DateTimeFormat(undefined, { weekday: "short" });
  const today = new Date();
  const days = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(today);
    date.setDate(today.getDate() - (6 - index));
    return {
      key: date.toISOString().slice(0, 10),
      label: formatter.format(date),
      minutes: 0
    };
  });

  for (const entry of entries) {
    const day = days.find(item => item.key === entry.started_at?.slice(0, 10));
    if (day) day.minutes += Number(entry.duration_minutes || 0);
  }

  if (days.every(day => day.minutes === 0)) {
    return days.map((day, index) => ({ ...day, minutes: [18, 34, 24, 48, 40, 58, 44][index] }));
  }
  return days;
}

function buildSubjectBreakdown(entries) {
  const totals = new Map();
  for (const entry of entries) {
    const subject = entry.subject || "General";
    totals.set(subject, (totals.get(subject) || 0) + Number(entry.duration_minutes || 0));
  }
  const fallback = [
    ["Maths", 90],
    ["Physics", 64],
    ["CS", 52]
  ];
  const rows = totals.size ? [...totals.entries()] : fallback;
  const total = rows.reduce((sum, [, minutes]) => sum + minutes, 0) || 1;
  const colors = ["#67e8f9", "#a78bfa", "#6ee7b7", "#fbbf24", "#fb7185"];
  return rows
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4)
    .map(([label, minutes], index) => ({
      label,
      minutes,
      percent: Math.max(8, Math.round((minutes / total) * 100)),
      color: colors[index % colors.length]
    }));
}

function getProductivityScore(stats) {
  const focus = Math.min(45, Math.round((stats.todayMinutes / 180) * 45));
  const tasks = Math.min(30, stats.completedTasks * 8);
  const pomodoros = Math.min(25, stats.focusSessions * 5);
  return Math.max(18, Math.min(99, focus + tasks + pomodoros));
}

function formatMinutes(minutes) {
  const hCount = Math.floor(minutes / 60);
  const mCount = minutes % 60;
  return hCount ? `${hCount}h ${mCount}m` : `${mCount}m`;
}

function formatClock(seconds) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const secs = (seconds % 60).toString().padStart(2, "0");
  return `${minutes}:${secs}`;
}

function datetimeLocalValue(date) {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60000).toISOString().slice(0, 16);
}

function title(value) {
  return value[0].toUpperCase() + value.slice(1);
}

const spring = { type: "spring", stiffness: 140, damping: 18 };
const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.12 } } };
const rise = { hidden: { opacity: 0, y: 22 }, show: { opacity: 1, y: 0, transition: spring } };

createRoot(document.querySelector("#app")).render(h(App));
