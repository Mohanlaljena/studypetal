# StudyPetal Supabase App

Vite + React frontend for StudyPetal with Supabase authentication, protected dashboard routes, planner tasks, screen time entries, Pomodoro sessions, analytics events, and installed Framer Motion animations.

## Supabase setup

1. Create a Supabase project.
2. Open the SQL editor and run `supabase/schema.sql`.
3. In Authentication > URL Configuration, add your Netlify URL and local URL to the allowed redirect URLs.
4. Copy your project URL and public anon key.

## Local setup

Install dependencies:

```bash
npm install
```

Create `.env` with Vite Supabase variables:

```bash
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_ANON_KEY=your-public-anon-key
```

Run locally:

```bash
npm run dev
```

Build for production:

```bash
npm run build
```

## Netlify setup

Set these environment variables in Netlify:

```bash
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_ANON_KEY=your-public-anon-key
```

Netlify runs `npm run build` and publishes `dist`. The app uses Supabase row level security for all data access.

## Tables

- `profiles`
- `screen_time_entries`
- `pomodoro_sessions`
- `study_planner_tasks`
- `analytics_events`

All user-owned tables have RLS enabled and policies limiting CRUD access to `auth.uid()`.
