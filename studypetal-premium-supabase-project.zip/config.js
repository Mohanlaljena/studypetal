window.STUDYPETAL_CONFIG = {
  "SUPABASE_URL": "https://wipvvnlcxkgdgbcfvsds.supabase.co",
  "SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndpcHZ2bmxjeGtnZGdiY2Z2c2RzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzk3MTQwOTAsImV4cCI6MjA5NTI5MDA5MH0.0usSK2aLMqCImc8Y7nZBgMR8yYOrk8Zur__cPzYEitk"
};
